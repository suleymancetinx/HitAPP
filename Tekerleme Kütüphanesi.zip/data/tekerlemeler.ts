export interface Tekerleme {
  id: string;
  harf: string;
  metin: string;
  zorluk: "kolay" | "orta" | "zor";
}

export const turkAlfabesi = [
  "A", "B", "C", "Ç", "D", "E", "F", "G", "Ğ", "H",
  "I", "İ", "J", "K", "L", "M", "N", "O", "Ö", "P",
  "R", "S", "Ş", "T", "U", "Ü", "V", "Y", "Z"
] as const;

export type TurkHarfi = typeof turkAlfabesi[number];

export const tekerlemeler: Record<TurkHarfi, string[]> = {
  "A": [
    "Aşçı Abbas armut alır, armutları aşırır, aşırdığı armutları artık aramaz.",
    "Al atı at, at atı al, al atı at altına al, at altındaki atı al.",
    "Acı acı acılar, acı acıdan acılar, acı acıya acılar, acı acıdan acılar mı?",
    "Akla akıl akmaz ama akıllı akla akar, akılsız akla akmaz akıl akılı arar.",
    "Ankara'dan Adana'ya armut alıp, Adana'dan Ankara'ya ayva alıp, avuçlarında armut ayva artırdı."
  ],
  "B": [
    "Bir berber bir berbere gel beraber bir berber dükkanı açalım demiş.",
    "Bu bulgur mu yoksa bulgur bunu bulgur bulgurcuya sor bulgur bulgurcudan bul.",
    "Bak bakkalın bakraçları, bakraçların kulpları, kulpların bakraçları, bakraçların bakkalları.",
    "Bülbül bülbülü bıktırdı, bülbül bıkmadı, bülbül bülbüle bülbüllük bıraktı.",
    "Bursa'dan balık bulundu, bu balık bolca bulundu, bu balık buraya bolca buradan buraya bulundu."
  ],
  "C": [
    "Cırcır böceği cıvıl cıvıl cıvıldar, cıvıldayan cırcır cıvıldamaktan cansız kalır.",
    "Cam camdan cam pencere, cam pencere camcıdan, camcı camdan cam alır, camı pencereye takar.",
    "Ceviz cevizlikte cilveleşir, cilveli ceviz cevizlikte cilvesini cibilliyetsizce cilveler.",
    "Cacık cacıkçıdan cacık, cacık cacıkçıya cık, cacıkçı cacıkla cıkıştı, cacık cıkıştıkça cık.",
    "Cumartesi cuma, cuma cumartesi, cuma cumartesiye cumartesi cumaya cümle cümle cuk."
  ],
  "Ç": [
    "Çoban çöpünü çuvalına çaldı, çuvaldan çöpünü çekti çıkardı.",
    "Çiçekçi çiçek çırpındı, çırpınan çiçek çiçekçiye çırpındıkça çırpındı.",
    "Çatal çukura çöktü, çukur çatala çöktü, çatal çukurdan çıktı, çukur çataldan çıktı.",
    "Çarşıda çarşaf çalan çapkın çocuk çarşafı çarçur çarptı.",
    "Çinko çini çizdi, çini çinkoyu çizdi, çinko çiniyle çizişti, çini çinkoyla çizişti."
  ],
  "D": [
    "Dal dalda dallanır, dallanınca dal budak, budakta dal dallanır, dalda budak budaklanır.",
    "Deve deve deve deve, deveye deve dedim, deve deveye deve dedi, deve deveden deve.",
    "Dandik dandikçi dandik, dandikçi dandik dandiği, dandiğin dandikçisi dandik.",
    "Dondurma dondurur dondurmacıyı, dondurmacı dondurur dondurmayı dondurarak.",
    "Düdük düdükçüde düdük, düdükçü düdüğü düdükler, düdük düdükçüde düdüklenince düdükler."
  ],
  "E": [
    "Ebe ebemgümeci eker, eken ebe ebemgümecini ekmiş, ekmiş de ekene ekeği ekmiş.",
    "El elden el alır, el ele el verir, elden ele el geçer, el elinden el alır.",
    "Erik eriklikte eridi, eriyen erik eriklikte erikleşti, erikleşen erik erikte eridi.",
    "Eşek eşeğe eşeklik eder, eşeklik eden eşek eşekten eşeklik öğrenir.",
    "Ev evde ev, evdeki ev evde, evde evdeki ev evde evlenir, evlenen ev evde ev."
  ],
  "F": [
    "Fırıncı fırınında fırın fırınlar, fırınlanan fırın fırıncıda fırınlanır.",
    "Fil file fil, fildeki fil filde, filde fildeki fil filde fil filler.",
    "Fıstık fıstıkçıda fıstık, fıstıkçı fıstıkta fıstık, fıstık fıstıkçıda fıstıklanır.",
    "Fare fareye fare fare dedi, fare fareden fare fare duyunca fareleşti.",
    "Fener fenerde fener, fenerdeki fener fenerde, fener fenerde fenerleşir fenerle."
  ],
  "G": [
    "Gaga gagada gaga, gagadaki gaga gagada, gaga gagada gagalar gagayı gagalar.",
    "Gül gülde güler, gülde gülen gül gülde gülünce gülümser gül gülde.",
    "Gürültü gürültücü gürültü, gürültücü gürültüde gürültü, gürültü gürültüler.",
    "Geyik geyikte geyik, geyikteki geyik geyikte, geyik geyikte geyikleşir.",
    "Gözlük gözlükçüde gözlük, gözlükçü gözlükte gözlük, gözlük gözlükçüde gözlenir."
  ],
  "Ğ": [
    "Dağ dağa dağ değdi, değen dağ dağdan dağıldı, dağılan dağ dağa değdi.",
    "Bağ bağda bağ, bağdaki bağ bağda, bağ bağda bağlanır bağla bağa bağlanır.",
    "Yağ yağda yağ, yağdaki yağ yağda, yağ yağda yağlanır yağla yağa yağlanır.",
    "Çağ çağa çağ, çağdaki çağ çağda, çağ çağda çağlar çağla çağa çağlar.",
    "Sağ sağa sağ, sağdaki sağ sağda, sağ sağda sağlanır sağla sağa sağlanır."
  ],
  "H": [
    "Horoz horoza horoz dedi, horoz horozdan horozlandı, horozlanan horoz horozladı.",
    "Havuç havuçta havuç, havuçtaki havuç havuçta, havuç havuçta havuçlanır.",
    "Hırka hırkada hırka, hırkadaki hırka hırkada, hırka hırkada hırkalanır.",
    "Hızlı hız hızlandı, hızlanan hız hızla hızlandı, hızlandıkça hız hızlandı.",
    "Hulusi helvacı helva halletti, hallettikçe helva hızla hallaç hallaçladı."
  ],
  "I": [
    "Irgat ırgatlıkta ırgat, ırgattaki ırgat ırgatlıkta, ırgat ırgatlıkta ırgatlanır.",
    "Ilık ılık ılık ılık, ılıklık ılıkta ılık, ılık ılıklıkta ılıklanır.",
    "Isıran ısırık ısırdı, ısırdıkça ısırık ısırdı, ısırıkla ısırık ısırıldı.",
    "Islak ıslaklıkta ıslak, ıslaklıktaki ıslak ıslaklıkta, ıslak ıslaklıkta ıslanır.",
    "Irmak ırmakta ırmak, ırmaktaki ırmak ırmakta, ırmak ırmakta ırmaklanır."
  ],
  "İ": [
    "İbiş ibikte ibiş, ibikteki ibiş ibikte, ibiş ibikte ibişleşir ibişle.",
    "İğne iğnede iğne, iğnedeki iğne iğnede, iğne iğnede iğnelenir iğneyle.",
    "İnci incide inci, incideki inci incide, inci incide incilenir inciyle.",
    "İplik iplikte iplik, iplikteki iplik iplikte, iplik iplikte ipliklenir iplikle.",
    "İşçi işte iş işler, işleyen işçi işte işlenir, işlenen iş işçide işlenir."
  ],
  "J": [
    "Jilet jilette jilet, jiletteki jilet jilette, jilet jilette jiletlenir jiletle.",
    "Jeton jetonda jeton, jetondaki jeton jetonda, jeton jetonda jetonlanır jetonla.",
    "Jel jelde jel, jeldeki jel jelde, jel jelde jellenir jelle jellenerek.",
    "Jandarma jandarmada jandarma, jandarmadaki jandarma jandarmada jandarmalaşır.",
    "Jüri jüride jüri, jürideki jüri jüride, jüri jüride jürileşir jüriyle."
  ],
  "K": [
    "Kara karga kapkara, kapkara karga kara, kara kargaya kapkara karga karar kıldı.",
    "Kuşkonmaz kuşları kondurmaz, kondurmayan kuşkonmaz kuşkonmazda kuşları kondurmaz.",
    "Kırk küp kırk küpün kulpu kırık küp, kırık küpün kırk kulpu kırık.",
    "Karınca karıncaya karınca, karınca karıncadan karıncalandı, karıncalanan karınca.",
    "Köpek köpekte köpek, köpekteki köpek köpekte, köpek köpekte köpekleşir."
  ],
  "L": [
    "Limon limonlukta limon, limonluktaki limon limonlukta, limon limonlukta limonlanır.",
    "Lale lalede lale, laledeki lale lalede, lale lalede lalelenir laleyle.",
    "Lokum lokumda lokum, lokumdaki lokum lokumda, lokum lokumda lokumlanır.",
    "Lamba lambada lamba, lambadaki lamba lambada, lamba lambada lambalanır.",
    "Levrek levrekçide levrek, levrekçideki levrek levrekçide, levrek levrekçide levrekleşir."
  ],
  "M": [
    "Muhallebi muhallebiciye muhallebi, muhallebici muhallebicilik mumu mumlarken muhallebiyi mahvetti.",
    "Martı martıda martı, martıdaki martı martıda, martı martıda martılaşır.",
    "Mor menekşe mor mor, mor morlukta menekşe mor, menekşe morlukta morardı.",
    "Merdiven merdivende merdiven, merdivende merdiven merdivenleşir merdivenle.",
    "Musluk muslukta musluk, musluktaki musluk muslukta, musluk muslukta musluklanır."
  ],
  "N": [
    "Nar narenciyede nar, narenciyedeki nar narenciyede, nar narenciyede narengilenin.",
    "Nur nurda nur, nurdaki nur nurda, nur nurda nurlanır nurla nurlanarak.",
    "Niyet niyette niyet, niyetteki niyet niyette, niyet niyette niyetlenir niyetle.",
    "Nane nanede nane, nanedeki nane nanede, nane nanede nanelenir naneyle.",
    "Nehir nehirde nehir, nehirdeki nehir nehirde, nehir nehirde nehirlenir nehirle."
  ],
  "O": [
    "Odun oduncuda odun, oduncudaki odun oduncuda, odun oduncuda odunlaşır.",
    "Orak orakta orak, oraktaki orak orakta, orak orakta oraklanır orakla.",
    "Otobüs otobüste otobüs, otobüsteki otobüs otobüste, otobüs otobüste otobüsleşir.",
    "Oda odada oda, odadaki oda odada, oda odada odalanır odayla.",
    "Orkide orkidede orkide, orkidedeki orkide orkidede, orkide orkidede orkidelenir."
  ],
  "Ö": [
    "Ördek ördeklekte ördek, ördeklekteki ördek ördeklekte, ördek ördeklekte ördekleşir.",
    "Örgü örgüde örgü, örgüdeki örgü örgüde, örgü örgüde örgülenir örgüyle.",
    "Öküz öküzde öküz, öküzdeki öküz öküzde, öküz öküzde öküzleşir öküzle.",
    "Öğretmen öğretmenlikte öğretmen, öğretmenlikte öğretmen öğretmenleşir.",
    "Örs örste örs, örsteki örs örste, örs örste örslenir örsle örslenerek."
  ],
  "P": [
    "Papağan papağana papağan, papağandaki papağan papağanda, papağan papağanlaşır.",
    "Pirincin pirinci pirince pirinçlenirken pirinçlerin pirinci pirinçlendi.",
    "Parmak parmakta parmak, parmaktaki parmak parmakta, parmak parmakta parmaklanır.",
    "Portakal portakalda portakal, portakaldaki portakal portakalda portakallaşır.",
    "Peynir peynirde peynir, peynirdeki peynir peynirde, peynir peynirde peynirlenir."
  ],
  "R": [
    "Rüzgar rüzgarda rüzgar, rüzgardaki rüzgar rüzgarda, rüzgar rüzgarda rüzgarlanır.",
    "Rende rendede rende, rendedeki rende rendede, rende rendede rendelenir rendeyle.",
    "Radyo radyoda radyo, radyodaki radyo radyoda, radyo radyoda radyolanır.",
    "Renk renkte renk, renkteki renk renkte, renk renkte renklenir renkle.",
    "Robot robotta robot, robottaki robot robotta, robot robotta robotlanır robotla."
  ],
  "S": [
    "Sarı saçlı sarışın saksıda sarı sarımsak saksıyla sarı sakız.",
    "Su suda su, sudaki su suda, su suda sulanır suyla sulanarak.",
    "Serçe serçede serçe, serçedeki serçe serçede, serçe serçede serçelenir.",
    "Sinek sinekte sinek, sinekteki sinek sinekte, sinek sinekte sineklenir sinekle.",
    "Sakız sakızda sakız, sakızdaki sakız sakızda, sakız sakızda sakızlanır sakızla."
  ],
  "Ş": [
    "Şeker şekerlemede şekerci şekeri şekerletti şekerleyince şekerleşti.",
    "Şemsiye şemsiyede şemsiye, şemsiyedeki şemsiye şemsiyede şemsiyelenir.",
    "Şimşek şimşekte şimşek, şimşekteki şimşek şimşekte, şimşek şimşekleşir.",
    "Şeftali şeftalide şeftali, şeftalideki şeftali şeftalide şeftalilenir.",
    "Şapka şapkada şapka, şapkadaki şapka şapkada, şapka şapkada şapkalanır."
  ],
  "T": [
    "Tavşan tavşana tavşan, tavşandaki tavşan tavşanda, tavşan tavşanda tavşanlaşır.",
    "Tren trende tren, trendeki tren trende, tren trende trenlenir trenle.",
    "Turuncu turunçgilde turunç, turunçgildeki turunç turunçgilde turuncuyadı.",
    "Tarak tarakta tarak, taraktaki tarak tarakta, tarak tarakta taraklanır tarakla.",
    "Terazi terazide terazi, terazideki terazi terazide, terazi terazide terazilenir."
  ],
  "U": [
    "Un uncuda un, uncudaki un uncuda, un uncuda unlanır unla unlanarak.",
    "Uçak uçakta uçak, uçaktaki uçak uçakta, uçak uçakta uçaklanır uçakla.",
    "Uzun uzunlukta uzun, uzunluktaki uzun uzunlukta, uzun uzunlukta uzunlaşır.",
    "Uyku uykuda uyku, uykudaki uyku uykuda, uyku uykuda uykulanır uykuyla.",
    "Usta ustalıkta usta, ustalıktaki usta ustalıkta, usta ustalıkta ustalaşır."
  ],
  "Ü": [
    "Üzüm üzümlükte üzüm, üzümlükteki üzüm üzümlükte, üzüm üzümlükte üzümlenir.",
    "Ütü ütüde ütü, ütüdeki ütü ütüde, ütü ütüde ütülenir ütüyle ütülenerek.",
    "Ümit ümitte ümit, ümitteki ümit ümitte, ümit ümitte ümitlenir ümitle.",
    "Üflemek üfleyerek üfledi, üfleyen üfledi, üfledikçe üfleyici üfledi.",
    "Ünlü ünlülükte ünlü, ünlülükteki ünlü ünlülükte, ünlü ünlülükte ünlülenir."
  ],
  "V": [
    "Vapur vapurda vapur, vapurdaki vapur vapurda, vapur vapurda vapurlanır.",
    "Vişne vişnede vişne, vişnedeki vişne vişnede, vişne vişnede vişnelenir.",
    "Vida vidada vida, vidadaki vida vidada, vida vidada vidalanır vidayla.",
    "Vazo vazoda vazo, vazodaki vazo vazoda, vazo vazoda vazolanır vazoyla.",
    "Vinç vinçte vinç, vinçteki vinç vinçte, vinç vinçte vinçlenir vinçle."
  ],
  "Y": [
    "Yağmur yağmurda yağmur, yağmurdaki yağmur yağmurda, yağmur yağmurda yağmurlanır.",
    "Yılan yılanda yılan, yılandaki yılan yılanda, yılan yılanda yılanlaşır.",
    "Yoğurt yoğurtta yoğurt, yoğurttaki yoğurt yoğurtta, yoğurt yoğurtta yoğurtlanır.",
    "Yaprak yaprakta yaprak, yapraktaki yaprak yaprakta, yaprak yaprakta yapraklanır.",
    "Yüzük yüzükte yüzük, yüzükteki yüzük yüzükte, yüzük yüzükte yüzüklenir."
  ],
  "Z": [
    "Zeytin zeytinde zeytin, zeytindeki zeytin zeytinde, zeytin zeytinde zeytinlenir.",
    "Zürafa zürafada zürafa, zürafadaki zürafa zürafada, zürafa zürafada zürafalaşır.",
    "Zambak zambakta zambak, zambaktaki zambak zambakta, zambak zambakta zambaklanır.",
    "Zil zilde zil, zildeki zil zilde, zil zilde zillenir zille zillenererek.",
    "Zaman zamanda zaman, zamandaki zaman zamanda, zaman zamanda zamanlanır zamanla."
  ]
};

// Tüm tekerlemeleri düz liste olarak al
export function getAllTekerlemeler(): Tekerleme[] {
  const result: Tekerleme[] = [];
  
  turkAlfabesi.forEach((harf) => {
    tekerlemeler[harf].forEach((metin, index) => {
      result.push({
        id: `${harf}-${index}`,
        harf,
        metin,
        zorluk: "orta"
      });
    });
  });
  
  return result;
}

// Belirli bir harfe göre tekerlemeleri getir
export function getTekerlemelerByHarf(harf: TurkHarfi): Tekerleme[] {
  return tekerlemeler[harf].map((metin, index) => ({
    id: `${harf}-${index}`,
    harf,
    metin,
    zorluk: "orta" as const
  }));
}

import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { BookOpen, Sparkles } from "lucide-react";

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md border-amber-200 shadow-xl">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-amber-100 rounded-full flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-amber-600" />
          </div>
          <CardTitle className="text-3xl font-bold text-amber-900">Türkçe Tekerlemeler</CardTitle>
          <CardDescription className="text-amber-700">
            Türk alfabesindeki 29 harf için 145 özgün tekerleme
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Link href="/tekerlemeler" className="block">
            <Button className="w-full bg-amber-600 hover:bg-amber-700 text-white py-6 text-lg">
              <BookOpen className="w-5 h-5 mr-2" />
              Tekerlemeleri Keşfet
            </Button>
          </Link>
          <p className="text-center text-sm text-amber-600">
            Her harf için 5 farklı tekerleme ile dilinizi çalıştırın!
          </p>
        </CardContent>
      </Card>
    </main>
  );
}

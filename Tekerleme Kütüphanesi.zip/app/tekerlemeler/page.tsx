"use client";

import { useState, useMemo } from "react";
import { turkAlfabesi, tekerlemeler, type TurkHarfi } from "@/data/tekerlemeler";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import Link from "next/link";
import { ArrowLeft, Volume2, Copy, Check, Shuffle } from "lucide-react";

export default function TekerlemelerPage() {
  const [selectedHarf, setSelectedHarf] = useState<TurkHarfi | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredTekerlemeler = useMemo(() => {
    if (!selectedHarf) {
      // Tüm harflerden tekerlemeleri göster
      return turkAlfabesi.flatMap((harf) =>
        tekerlemeler[harf].map((metin, index) => ({
          id: `${harf}-${index}`,
          harf,
          metin,
        }))
      );
    }
    return tekerlemeler[selectedHarf].map((metin, index) => ({
      id: `${selectedHarf}-${index}`,
      harf: selectedHarf,
      metin,
    }));
  }, [selectedHarf]);

  const handleCopy = async (id: string, metin: string) => {
    await navigator.clipboard.writeText(metin);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleSpeak = (metin: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(metin);
      utterance.lang = "tr-TR";
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  const getRandomTekerleme = () => {
    const allTekerlemeler = turkAlfabesi.flatMap((harf) =>
      tekerlemeler[harf].map((metin) => ({ harf, metin }))
    );
    const random = allTekerlemeler[Math.floor(Math.random() * allTekerlemeler.length)];
    setSelectedHarf(random.harf);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-orange-50">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-amber-200">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="ghost" size="icon">
                  <ArrowLeft className="h-5 w-5" />
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold text-amber-900">Tekerleme Kütüphanesi</h1>
                <p className="text-sm text-amber-700">
                  Türk alfabesindeki 29 harf için {29 * 5} tekerleme
                </p>
              </div>
            </div>
            <Button
              onClick={getRandomTekerleme}
              variant="outline"
              className="border-amber-300 hover:bg-amber-100"
            >
              <Shuffle className="h-4 w-4 mr-2" />
              Rastgele
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Harf Filtreleme */}
        <div className="mb-8">
          <h2 className="text-lg font-semibold text-amber-900 mb-4">Harfe Göre Filtrele</h2>
          <div className="flex flex-wrap gap-2">
            <Button
              variant={selectedHarf === null ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedHarf(null)}
              className={
                selectedHarf === null
                  ? "bg-amber-600 hover:bg-amber-700"
                  : "border-amber-300 hover:bg-amber-100"
              }
            >
              Tümü
            </Button>
            {turkAlfabesi.map((harf) => (
              <Button
                key={harf}
                variant={selectedHarf === harf ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedHarf(harf)}
                className={
                  selectedHarf === harf
                    ? "bg-amber-600 hover:bg-amber-700"
                    : "border-amber-300 hover:bg-amber-100"
                }
              >
                {harf}
              </Button>
            ))}
          </div>
        </div>

        {/* Sonuç Sayısı */}
        <div className="mb-4">
          <Badge variant="secondary" className="bg-amber-200 text-amber-900">
            {filteredTekerlemeler.length} tekerleme bulundu
            {selectedHarf && ` (${selectedHarf} harfi)`}
          </Badge>
        </div>

        {/* Tekerlemeler Listesi */}
        <ScrollArea className="h-[calc(100vh-320px)]">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filteredTekerlemeler.map((tekerleme) => (
              <Card
                key={tekerleme.id}
                className="group hover:shadow-lg transition-all duration-300 border-amber-200 hover:border-amber-400 bg-white"
              >
                <CardContent className="p-5">
                  <div className="flex items-start justify-between mb-3">
                    <Badge
                      className="bg-amber-100 text-amber-800 border-amber-300 text-lg font-bold px-3 py-1"
                      variant="outline"
                    >
                      {tekerleme.harf}
                    </Badge>
                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-amber-600 hover:text-amber-800 hover:bg-amber-100"
                        onClick={() => handleSpeak(tekerleme.metin)}
                        title="Sesli oku"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-amber-600 hover:text-amber-800 hover:bg-amber-100"
                        onClick={() => handleCopy(tekerleme.id, tekerleme.metin)}
                        title="Kopyala"
                      >
                        {copiedId === tekerleme.id ? (
                          <Check className="h-4 w-4 text-green-600" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <p className="text-amber-950 leading-relaxed text-base">{tekerleme.metin}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </ScrollArea>
      </main>
    </div>
  );
}
